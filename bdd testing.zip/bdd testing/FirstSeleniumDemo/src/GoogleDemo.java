import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GoogleDemo {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Sanjay Data Backup\\Selenium\\Softwares\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		driver.get("http://www.google.com/");
	
	//	WebElement searchelement = driver.findElement(By.name("q"));
		WebElement searchelement = driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div[1]/div[1]/div/div[2]/input"));
		searchelement.sendKeys("Capgemini ");
		searchelement.submit();
		
		//1
	/*	WebElement searchelement=driver.findElement(By.name("q"));
		searchelement.sendKeys("Capgemini");
		searchelement.submit();*/
	
	
	
	//2
	/*WebElement searchelement=driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div[1]/div[1]/div/div[2]/input"));
	searchelement.sendKeys("Capgemini");
	searchelement.submit();*/
		
		/*List<WebElement>list=driver.findElements(By.tagName("a"));
		Iterator<WebElement> i=list.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next().getText());
		}*/
//		WebElement search=driver.findElement(By.xpath("//*[@name='q']"));
//		search.sendKeys("Capgemini");
//		System.out.println(search.getText());
//		search.submit();
//		
//		WebElement images=driver.findElement(By.linkText("Images"));
//		images.click();
		
//		WebElement searchelement=driver.findElement(By.name("q"));
////		//*[@id="fakebox-input"]
////		/html/body/div[4]/div[2]/div/input
//		searchelement.sendKeys("apple");
//		searchelement.submit();
//		if(driver.getTitle().equalsIgnoreCase("apple - Google Search"))
//		{
//			System.out.println("Correct Page");
//		}
//		else
//		{
//			System.out.println("Incorrect");
//		}
	}

}
