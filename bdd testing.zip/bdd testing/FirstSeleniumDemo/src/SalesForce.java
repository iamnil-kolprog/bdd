import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SalesForce {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Sanjay Data Backup\\Selenium\\Softwares\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://login.salesforce.com/?locale=in");
		driver.findElement(By.id("username")).sendKeys("hello");
		driver.findElement(By.name("pw")).sendKeys("hello");
		//driver.findElement(By.className("button r4 wide primary")); //invalid selector: Compound class names not permitted
		//driver.findElement(By.xpath("//*[@id=\"Login\"]"));   ////*[@id="Login"]
		
		driver.findElement(By.xpath("//*[@id=\"Login\"]")).click();;
	}

}
