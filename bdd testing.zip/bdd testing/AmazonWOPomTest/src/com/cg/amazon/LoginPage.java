package com.cg.amazon;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
	
	WebDriver web;
	
	public LoginPage(WebDriver web) {
		//super();
		this.web = web;
	}

	By uName = By.name("email");
	By cont = By.id("continue");
	By pW = By.name("password");
	By login = By.id("signInSubmit");
	
	public WebElement userName() {
		return  web.findElement(uName);
		
	}
	public WebElement cntnue() {
		return  web.findElement(pW);
	}
	public WebElement pass() {
		return web.findElement(pW);
	}
	public WebElement login() {
		return web.findElement(login);
	}

}
