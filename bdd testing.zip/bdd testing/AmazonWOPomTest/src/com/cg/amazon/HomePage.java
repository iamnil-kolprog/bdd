package com.cg.amazon;

public class HomePage {

}
