package com.capg.stepDefinition;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginTest {
	
	
	WebDriver driver;
	
	@Given("^Open google chrome start application$")
	public void open_google_chrome_start_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\NILANSAH\\Desktop\\Testing mod 4\\chromedriverLatest\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	    driver.get("https://www.amazon.in/ap/signin?openid.assoc_handle=inflex&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2F%3Fref_%3Dnav_em_link_re_signin%26_encoding%3DUTF8&ref_=nav_em_T1_0_1_0_4_link_clc_signin");
	}

	@When("^I enter valid username and password$")
	public void i_enter_valid_username_and_password() throws Throwable {
	   driver.findElement(By.id("ap_email")).sendKeys("7081615618");
	   driver.findElement(By.id("continue")).submit();
	   
	   driver.findElement(By.id("ap_password")).sendKeys("wishmeon25");
	   driver.findElement(By.id("signInSubmit")).submit();
	   
	}

	@Then("^User should be able to login successfully\\.$")
	public void user_should_be_able_to_login_successfully() throws Throwable {
		assertEquals("Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in", driver.getTitle());
		
	}
}
