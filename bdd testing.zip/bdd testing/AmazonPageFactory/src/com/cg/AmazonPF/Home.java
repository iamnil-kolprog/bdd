package com.cg.AmazonPF;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Home {
	
	WebDriver web;

	public Home(WebDriver web) {
		super();
		this.web = web;
	}
	
	@FindBy(id="twotabsearchtextbox")
	WebElement searchbox;
	
	@FindBy(xpath="//*[@id=\"nav-search\"]/form/div[2]/div/input")
	WebElement search;
	
	@FindBy(xpath="//*[@id=\"search\"]/div[1]/div[2]/div/span[4]/div[1]/div[1]/div/span/div/div/div[2]/div[2]/div/div[1]/div/div/div[1]/h2/a/span")
	WebElement iphn;
	
	
	public void searchProduct(String prod) {
		searchbox.sendKeys(prod);
		search.submit();
		iphn.click();;
	}

}
