package com.cg.AmazonPF;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class Login {
	
	WebDriver driver;
	
	
	public Login(WebDriver driver) {
	
		this.driver = driver;
	}

	@FindBy(name="email")
	WebElement userName;
	
	@FindBy(id="continue")
	WebElement cont;
	
	@FindBy(name="password")
	WebElement pW;
	
	@FindBy(id="signInSubmit")
	WebElement signIn;
	
	public void login_Amazon(String uid,String pw) {
		userName.sendKeys(uid);
		cont.submit();
		pW.sendKeys(pw);
		signIn.submit();
	}

}
