package com.cg.AmazonPF;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AddToCart {
	
	WebDriver cart;

	public AddToCart(WebDriver cart) {
		super();
		this.cart = cart;
	}
	
	@FindBy(id="add-to-wishlist-button-submit")
	WebElement addTo;
	
	public void ADD() {
		addTo.submit();
	}

}
