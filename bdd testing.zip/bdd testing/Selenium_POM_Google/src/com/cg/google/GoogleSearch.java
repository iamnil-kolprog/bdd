package com.cg.google;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class GoogleSearch 
{
	WebDriver driver;
	public GoogleSearch(WebDriver driver) 
	{
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	
   By searchbox =By.xpath("//*[@id=\"tsf\"]/div[2]/div[1]/div[1]/div/div[2]/input");
//   By Password=By.name("passwd");
   By go=By.name("btnK");
//   By home=By.linkText("Home");
   
   
   public WebElement search()
   {
	   return driver.findElement(searchbox);
   }
   
         
//   public WebElement Password()
//   {
//	   return driver.findElement(Password);
//   }
//   
   public WebElement submit()
   {
	   return driver.findElement(go);
  }
//   
//   public WebElement Home()
//   {
//	   return driver.findElement(home);
//   }
//	

	
	
	

}
