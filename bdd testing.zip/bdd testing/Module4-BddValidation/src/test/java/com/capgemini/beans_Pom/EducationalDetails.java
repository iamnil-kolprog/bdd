package com.capgemini.beans_Pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EducationalDetails {
	
	WebDriver driver;
	
	
	public EducationalDetails(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(name="graduation")
	WebElement graduation;
	
	@FindBy(name="percentage")
	WebElement percentage;
	
	@FindBy(name="passingYear")
	WebElement passYear;
	
	@FindBy(name="projectName")
	WebElement projectName;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/input[1]")
	WebElement dotNet;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/input[2]")
	WebElement java;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/input[3]")
	WebElement php;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/input[4]")
	WebElement other;
	
	@FindBy(id="btnRegister")
	WebElement registerMe;
	
	@FindBy(name="otherTechnologies")
	WebElement otherTech;


	public WebElement getGraduation() {
		return graduation;
	}

	public void setGraduation(String graduation) {
		this.graduation.sendKeys(graduation);
	}

	public WebElement getPercentage() {
		return percentage;
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}

	public WebElement getPassYear() {
		return passYear;
	}

	public void setPassYear(String passYear) {
		this.passYear.sendKeys(passYear);
	}

	public WebElement getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);
	}

	public WebElement getDotNet() {
		return dotNet;
	}

	public void setDotNet(WebElement dotNet) {
		this.dotNet = dotNet;
	}

	public WebElement getJava() {
		return java;
	}

	public void setJava(WebElement java) {
		this.java = java;
	}

	public WebElement getPhp() {
		return php;
	}

	public void setPhp(WebElement php) {
		this.php = php;
	}

	public WebElement getOther() {
		return other;
	}

	public void setOther(WebElement other) {
		this.other = other;
	}

	public WebElement getRegisterMe() {
		return registerMe;
	}

	public void setRegisterMe(WebElement registerMe) {
		this.registerMe = registerMe;
	}

	public WebElement getOtherTech() {
		return otherTech;
	}

	public void setOtherTech(String otherTech) {
		this.otherTech.sendKeys(otherTech);
	}
	
	
}
