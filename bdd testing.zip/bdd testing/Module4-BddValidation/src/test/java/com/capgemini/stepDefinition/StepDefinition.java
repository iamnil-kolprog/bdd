package com.capgemini.stepDefinition;

import static org.junit.Assert.assertEquals;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.capgemini.beans_Pom.EducationalDetails;
import com.capgemini.beans_Pom.PersonalDetails;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	
	WebDriver driver;
	PersonalDetails personal_details;
	EducationalDetails educational_details;
	
	@Given("^User is on Registration Form page$")
	public void user_is_on_Registration_Form_page()  {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\NILANSAH\\Desktop\\Testing mod 4\\chromedriverLatest\\chromedriver.exe");
		driver = new ChromeDriver();
		personal_details=new PersonalDetails(driver);							
		driver.manage().window().maximize();					//maximizing the window
		driver.get("file:///C:/Users/NILANSAH/Desktop/SET%20B/PersonalDetails.html#");		//open the Personal Details page
	}

	@Then("^Title should be \"([^\"]*)\"$")
	public void title_should_be(String arg1) {
	   assertEquals(driver.getTitle(),arg1);			//checking the title of the page
	    
	}
	@When("^Submit button is clicked without entering First_Name$")
	public void submit_button_is_clicked_without_entering_First_Name() throws Throwable {
	   personal_details.setfName("");				//setting empty string to firstname input field or we can comment this line.
	   Thread.sleep(500);
	   personal_details.getNext().click();			//clicking the Next link
	}

	@Then("^error message should be displayed as \"([^\"]*)\"$")
	public void error_message_should_be_displayed_as(String arg1){

		String alert = driver.switchTo().alert().getText();			//fetching the alert message from html page
		assertEquals(alert,arg1);
		driver.switchTo().alert().accept();						//click the 'OK' button of alert box
	}

	@When("^Submit button is clicked without entering Last_Name$")
	public void submit_button_is_clicked_without_entering_Last_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal_details.setfName("Nilanjan");
		Thread.sleep(500);
		personal_details.setlName("");
		Thread.sleep(500);
		personal_details.setNext();
	}

	@Then("^alert message should be displayed as \"([^\"]*)\"$")
	public void alert_message_should_be_displayed_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String alertLname = driver.switchTo().alert().getText();
		assertEquals(alertLname,arg1);
		driver.switchTo().alert().accept();
	}

	@When("^Submit button is clicked without entering Email$")
	public void submit_button_is_clicked_without_entering_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal_details.setlName("Saha");
	    Thread.sleep(500);
	    personal_details.setEmail("");
	    Thread.sleep(500);
	    personal_details.setNext();
	}

	@Then("^error message should be come as \"([^\"]*)\"$")
	public void error_message_should_be_come_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    String alertEmail=driver.switchTo().alert().getText();
	    assertEquals(alertEmail, arg1);
	    driver.switchTo().alert().accept();
	}
	
	@When("^Submit button is clicked entered by wrong format like \"([^\"]*)\"$")
	public void submit_button_is_clicked_entered_by_wrong_format_like(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 personal_details.setEmail(arg1);					//setting wrong format of email
		    Thread.sleep(500);		
		    personal_details.setNext();
	}

	@Then("^the alert message should be displayed as \"([^\"]*)\"$")
	public void the_alert_message_should_be_displayed_as(String arg1)  {
	    // Write code here that turns the phrase above into concrete actions
		 String alertEmail=driver.switchTo().alert().getText();
		   assertEquals(alertEmail, arg1);
		  driver.switchTo().alert().accept();
	}

	@When("^Submit button is clicked without entering Contact_No$")
	public void submit_button_is_clicked_without_entering_Contact_No() throws Throwable {
		personal_details.getEmail().clear();
		Thread.sleep(300);
	    personal_details.setEmail("nilsaha97@gmail.com");
	    Thread.sleep(500);
	    personal_details.setPhone("");
	    personal_details.setNext();
	}

	@Then("^alert should be displayed as \"([^\"]*)\"$")
	public void alert_should_be_displayed_as(String arg1) {
	   String alertPhone = driver.switchTo().alert().getText();
	   assertEquals(alertPhone, arg1);
	   driver.switchTo().alert().accept();

	}
	
	@When("^Submit button is clicked entered by wrong format in contact like \"([^\"]*)\"$")
	public void submit_button_is_clicked_entered_by_wrong_format_in_contact_like(String arg1) throws Throwable {
			personal_details.setPhone(arg1);
		    Thread.sleep(500);
		    personal_details.setNext();

	}

	@Then("^alert error message should be displayed as \"([^\"]*)\"$")
	public void alert_error_message_should_be_displayed_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		   String alertPhone = driver.switchTo().alert().getText();
		   assertEquals(alertPhone, arg1);
		   driver.switchTo().alert().accept();
	}

	@When("^Submit button is clicked without entering first address line$")
	public void submit_button_is_clicked_without_entering_first_address_line() throws Throwable{
		personal_details.getPhone().clear();
		personal_details.setPhone("9859478592");
	    Thread.sleep(500);
	    personal_details.setAdd1("");
	    personal_details.setNext();
	   
	}

	@Then("^error message for addressline should be displayed as \"([^\"]*)\"$")
	public void error_message_for_addressline_should_be_displayed_as(String arg1)  {
	    // Write code here that turns the phrase above into concrete actions
	    String add1 = driver.switchTo().alert().getText();
	    assertEquals(add1,arg1);
	    driver.switchTo().alert().accept();
	}

	@When("^Submit button is clicked without entering second address line$")
	public void submit_button_is_clicked_without_entering_second_address_line() throws Throwable {
		personal_details.setAdd1("3/54 jadavgarh");
	    Thread.sleep(500);
	    //personal_details.setAdd2("");
	    personal_details.setNext();
	}

	@Then("^error message for second addressline should be displayed as \"([^\"]*)\"$")
	public void error_message_for_second_addressline_should_be_displayed_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String add2 = driver.switchTo().alert().getText();
	    assertEquals(add2,arg1);
	    driver.switchTo().alert().accept();
	}

	@When("^Submit button is clicked without selecting the city$")
	public void submit_button_is_clicked_without_selecting_the_city() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal_details.setAdd2("Haltu");
		Thread.sleep(500);
	    personal_details.setNext();
	    Thread.sleep(500);
	}

	@Then("^error message for city should be displayed as \"([^\"]*)\"$")
	public void error_message_for_city_should_be_displayed_as(String arg1)  {
	    // Write code here that turns the phrase above into concrete actions
		String city = driver.switchTo().alert().getText();
	    assertEquals(city,arg1);
	    driver.switchTo().alert().accept();
	}

	@When("^Submit button is clicked without selecting the state$")
	public void submit_button_is_clicked_without_selecting_the_state() throws Throwable {
		personal_details.setCity("Pune");
	    Thread.sleep(500);
	    personal_details.setNext();
	    Thread.sleep(500);
	}

	@Then("^error message for state should be displayed as \"([^\"]*)\"$")
	public void error_message_for_state_should_be_displayed_as(String arg1) throws Throwable {
		String state = driver.switchTo().alert().getText();
	    assertEquals(state,arg1);
	    driver.switchTo().alert().accept();
	}

	@When("^Submit button is clicked After Validations$")
	public void submit_button_is_clicked_After_Validations() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal_details.setState("Karnataka");
		Thread.sleep(500);
		personal_details.setNext(); 
	}

	@Then("^alert message should come with as \"([^\"]*)\"$")
	public void alert_message_should_come_with_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String alert = driver.switchTo().alert().getText();
	    assertEquals(alert,arg1);
	    driver.switchTo().alert().accept();
	}
	
	
	
	
	
	@Given("^User is on Educational page$")
	public void user_is_on_Educational_page() throws Throwable {
		
		educational_details=new EducationalDetails(driver);
		
	}

	@Then("^Title might be \"([^\"]*)\"$")
	public void title_might_be(String arg1)  {
	    String title = driver.getTitle();
	    assertEquals(title, arg1);
	    
	}

	@When("^User is clicking the submit button without selecting the graduation field$")
	public void user_is_clicking_the_submit_button_without_selecting_the_graduation_field() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    educational_details.getRegisterMe().click();
	}

	@Then("^alert message for Graduation field should come as \"([^\"]*)\"$")
	public void alert_message_for_Graduation_field_should_come_as(String arg1) throws Throwable {
		String alertGraduation = driver.switchTo().alert().getText();
	    assertEquals(alertGraduation,arg1);
	    driver.switchTo().alert().accept();
	   
	}

	@When("^User is submitting without entering the Percentage field$")
	public void user_is_submitting_without_entering_the_Percentage_field() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Select grada=new Select(driver.findElement(By.name("graduation")));
        grada.selectByVisibleText("BTech");
        Thread.sleep(500);
        educational_details.setPercentage("");
        educational_details.getRegisterMe().click();
	}

	@Then("^alert message for percentage field should come as \"([^\"]*)\"$")
	public void alert_message_for_percentage_field_should_come_as(String arg1) throws Throwable {
		String alertPercentage = driver.switchTo().alert().getText();
	    assertEquals(alertPercentage,arg1);
	    driver.switchTo().alert().accept();
	    
	}

	@When("^User is submitting without entering the Passing Year$")
	public void user_is_submitting_without_entering_the_Passing_Year() throws Throwable {
	   educational_details.setPercentage("80%");
	   Thread.sleep(500);
	   educational_details.getRegisterMe().click();
	}

	@Then("^alert message for passing year should come as \"([^\"]*)\"$")
	public void alert_message_for_passing_year_should_come_as(String arg1) throws Throwable {
	   String passingYear= driver.switchTo().alert().getText();
	   assertEquals(passingYear, arg1);
	   driver.switchTo().alert().accept();
	}

	@When("^User is submitting without entering the Project Name$")
	public void user_is_submitting_without_entering_the_Project_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    educational_details.setPassYear("2019");
	    Thread.sleep(500);
	    educational_details.getRegisterMe().click();
	}

	@Then("^alert message for project name should come as \"([^\"]*)\"$")
	public void alert_message_for_project_name_should_come_as(String arg1) throws Throwable {
		String projectName= driver.switchTo().alert().getText();
		   assertEquals(projectName, arg1);
		   driver.switchTo().alert().accept();
	}

	@When("^User is submitting without clicking the Technologies Used$")
	public void user_is_submitting_without_clicking_the_Technologies_Used() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    educational_details.setProjectName("Banking App");
	    Thread.sleep(500);
	    educational_details.getRegisterMe().click();
	}

	@Then("^alert message technologies should come as \"([^\"]*)\"$")
	public void alert_message_technologies_should_come_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    String alertTech = driver.switchTo().alert().getText();
	    assertEquals(alertTech,arg1);
	    driver.switchTo().alert().accept();
	}

	@When("^User is submitting without writing the Other Technologies$")
	public void user_is_submitting_without_writing_the_Other_Technologies() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    educational_details.getPhp().click();
	    educational_details.getOther().click();
	    Thread.sleep(500);
	    educational_details.getRegisterMe().click();
	    
	}

	@Then("^alert message other technology should come as \"([^\"]*)\"$")
	public void alert_message_other_technology_should_come_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    String alertOtherTech = driver.switchTo().alert().getText();
	    assertEquals(alertOtherTech, arg1);
	    driver.switchTo().alert().accept();
	}

	@When("^User is submitting with all the details$")
	public void user_is_submitting_with_all_the_details() throws Throwable {
	    educational_details.setOtherTech("Python");
	    Thread.sleep(500);
	    educational_details.getRegisterMe().click();
	   
	}

	@Then("^Alert message for success should be displayed as \"([^\"]*)\"$")
	public void alert_message_for_success_should_be_displayed_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String success = driver.switchTo().alert().getText();
		assertEquals(success, arg1);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		driver.quit();					//closing the browser.
	}





}
