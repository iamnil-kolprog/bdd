package PageBean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegistrationPOM {

	WebDriver driver;
	
	@FindBy(id = "usrID")
	@CacheLookup
	WebElement userId;
	
	@FindBy(name = "passid")
	@CacheLookup
	WebElement password;
	
	@FindBy(id = "usrname")
	@CacheLookup
	WebElement name;
	
	@FindBy(id = "addr")
	@CacheLookup
	WebElement address;
	
	@FindBy(name = "country")
	@CacheLookup
	WebElement country;
	
	@FindBy(name = "zip")
	@CacheLookup
	WebElement zipCode;
	
	@FindBy(name = "email")
	@CacheLookup
	WebElement emailId;
	
	@FindBy(name = "sex")
	@CacheLookup
	WebElement gender;
	
	@FindBy(name = "en")
	@CacheLookup
	WebElement language;
	
	@FindBy(name = "submit")
	@CacheLookup
	WebElement submit;


	public RegistrationPOM(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getUserId() {
		return userId;
	}

	public void setUserId(String suserId) {
		this.userId.sendKeys(suserId);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String spassword) {
		this.password.sendKeys(spassword);
	}

	public WebElement getName() {
		return name;
	}

	public void setName(String sname) {
		this.name.clear();
		this.name.sendKeys(sname);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String saddress) {
		this.address.sendKeys(saddress);
	}

	public WebElement getCountry() {
		return country;
	}

	public void setCountry(String scountry) {
		Select dropCountry = new Select(country);
		dropCountry.selectByVisibleText(scountry);
	}

	public WebElement getZipCode() {
		return zipCode;
	}

	public void setZipCode(String szipCode) {
		this.zipCode.sendKeys(szipCode);
	}

	public WebElement getEmailId() {
		return emailId;
	}

	public void setEmailId(String semailId) {
		this.emailId.sendKeys(semailId);
	}

	public WebElement getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = driver.findElement(By.xpath(gender));
		this.gender.click();
	}

	public WebElement getLanguage() {
		return language;
	}

	public void setLanguage() {
		this.language.click();
	}
	
	public WebElement getSubmit() {
		return submit;
	}
	
	public void setSubmit() {
		this.submit.click();
	}
}
