package StepDefinition;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBean.RegistrationPOM;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	WebDriver driver;
	RegistrationPOM object;

	@Given("^User is on Registration Form page$")
	public void user_is_on_Registration_Form_page() throws Throwable {
		String projectLocation = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", projectLocation + "\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
		object = new RegistrationPOM(driver);
		driver.get(projectLocation + "\\view\\RegistrationForm.html");
	}

	@Then("^Title should be \"([^\"]*)\"$")
	public void title_should_be(String arg1) throws Throwable {
		String title = driver.getTitle();
		String title1 = "Welcome to JobsWorld";
		assertEquals(title, title1);
	}

	@When("^Submit button is clicked without entering User id or length of User id do not lie between (\\d+) to (\\d+)$")
	public void submit_button_is_clicked_without_entering_User_id_or_length_of_User_id_do_not_lie_between_to(int arg1, int arg2) throws Throwable {
		object.setUserId("");
		Thread.sleep(1000);
		object.setSubmit();
	}

	@Then("^error message should be displayed as \"([^\"]*)\"$")
	public void error_message_should_be_displayed_as(String arg1) throws Throwable {
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert, arg1);
		driver.switchTo().alert().accept();
	}

	@When("^Submit button is clicked without entering Password or length of Password do not lie between (\\d+) to (\\d+)$")
	public void submit_button_is_clicked_without_entering_Password_or_length_of_Password_do_not_lie_between_to(int arg1, int arg2) throws Throwable {
		object.setUserId("Yatharth123");
		Thread.sleep(100);
		object.setPassword("");
		Thread.sleep(1000);
		object.setSubmit();
	}

	@When("^Submit button is clicked without entering Name or entered Name contains any other characters except alphabets$")
	public void submit_button_is_clicked_without_entering_Name_or_entered_Name_contains_any_other_characters_except_alphabets() throws Throwable {
		object.setPassword("Dubey123");
		Thread.sleep(100);
		object.setName("");
		Thread.sleep(1000);
		object.setSubmit();
	}

	@When("^Submit button is clicked without entering Address or entered Address contains any other characters except alphanumeric characters$")
	public void submit_button_is_clicked_without_entering_Address_or_entered_Address_contains_any_other_characters_except_alphanumeric_characters() throws Throwable {
		object.setName("YatharthDubey");
		Thread.sleep(100);
		object.setAddress("");
		Thread.sleep(1000);
		object.setSubmit();
	}

	@When("^Submit button is clicked without selecting any Country$")
	public void submit_button_is_clicked_without_selecting_any_Country() throws Throwable {
		
		object.setAddress("ShaheedNagar");
		Thread.sleep(100);
		object.setSubmit();
	}

	@When("^Submit button is clicked without entering ZIP Code or entered ZIP Code contains any other characters except numbers$")
	public void submit_button_is_clicked_without_entering_ZIP_Code_or_entered_ZIP_Code_contains_any_other_characters_except_numbers() throws Throwable {
	
		object.setCountry("India");
		Thread.sleep(100);
		object.setZipCode("");
		Thread.sleep(1000);
		object.setSubmit();
	}

	@When("^Submit button is clicked without entering Email or entered Email is invalid like \"([^\"]*)\"$")
	public void submit_button_is_clicked_without_entering_Email_or_entered_Email_is_invalid_like(String arg1) throws Throwable {
		
		object.setZipCode("282001");
		Thread.sleep(100);
		object.setEmailId(arg1);
		Thread.sleep(1000);
		object.setSubmit();
	}

	@When("^Submit button is clicked without selecting any Sex$")
	public void submit_button_is_clicked_without_selecting_any_Sex() throws Throwable {
		
		object.setEmailId("yoyo@gmail.com");
		Thread.sleep(1000);
		
		object.setSubmit();
	}

	@When("^Subnmit button is clicked after entering all valid details$")
	public void subnmit_button_is_clicked_after_entering_all_valid_details() throws Throwable {
		
		object.setGender("html/body/form/ul/li[16]/input");
		Thread.sleep(100);
		object.setLanguage();
		Thread.sleep(1000);
		object.setSubmit();
	}

	@Then("^success message should be displayed as \"([^\"]*)\"$")
	public void success_message_should_be_displayed_as(String arg1) throws Throwable {
		String success = driver.switchTo().alert().getText();
		assertEquals(success, arg1);
		
	}
	

}
