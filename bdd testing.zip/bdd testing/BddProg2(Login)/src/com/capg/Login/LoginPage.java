package com.capg.Login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginPage {
	public static void main(String[] args) {
		
System.setProperty("webdriver.chrome.driver", "C:\\Users\\NILANSAH\\Desktop\\Testing mod 4\\chromedriverLatest\\chromedriver.exe");
		
		/*WebDriver driver=new ChromeDriver();
		driver.get("http://www.google.com/");*/
		
		
		/*WebElement searchelement = driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div[1]/div[1]/div/div[2]/input"));
		searchelement.sendKeys("GitHub");
		searchelement.submit();
		
		WebElement searchelement1 = driver.findElement(By.xpath("//*[@id=\"rso\"]/div[1]/div/div/div/div/div[1]/a/h3/span"));
		searchelement1.click();
		
		WebElement searchelement2 = driver.findElement(By.xpath("/html/body/div[1]/header/div/div[2]/div[2]/a[1]"));
		searchelement2.click();
		
		WebElement searchelement3 = driver.findElement(By.xpath("//*[@id=\"login_field\"]"));
		searchelement3.sendKeys("iamnil-kolprog");
		
		WebElement searchelement4 = driver.findElement(By.xpath("//*[@id=\"password\"]"));
		searchelement4.sendKeys("Nilsaha555");
		
		searchelement4.submit();*/
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.makemytrip.com");
		
		/*WebElement searchelement1 = driver.findElement(By.cssSelector("#wzrk-cancel"));
		searchelement1.submit();
*/		
		WebElement searchelement2 = driver.findElement(By.cssSelector("#SW > div.landingContainer > div.headerOuter > div > div > nav > ul > li:nth-child(9) > a > span.chNavText.darkGreyText"));
		searchelement2.click();
		
		
	}

}
