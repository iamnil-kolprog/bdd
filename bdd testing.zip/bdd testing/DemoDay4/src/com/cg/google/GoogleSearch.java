package com.cg.google;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class GoogleSearch 
{
	WebDriver driver;
	public GoogleSearch(WebDriver driver) 
	{

		this.driver=driver;
	}
	
	By searchbox =By.xpath("//*[@id=\"tsf\"]/div[2]/div[1]/div[1]/div/div[2]/input");

	By go=By.name("btnK");

   
   
   public void typeSearch(String s)
   {
	    driver.findElement(searchbox).sendKeys(s);
   }
   
   public void clickSubmit()
   {
	   driver.findElement(go).click();
  }


}
