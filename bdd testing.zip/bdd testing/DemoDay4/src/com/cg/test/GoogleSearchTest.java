package com.cg.test;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.google.GoogleSearch;
import com.google.common.annotations.VisibleForTesting;


public class GoogleSearchTest 
{
	@Test
	public void searchTest()
	{
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\NILANSAH\\Desktop\\Testing mod 4\\chromedriverLatest\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.com/");
		
		GoogleSearch gs = new GoogleSearch(driver);
	
		gs.typeSearch("football");
		
		gs.clickSubmit();
		
		driver.quit();

}
}
