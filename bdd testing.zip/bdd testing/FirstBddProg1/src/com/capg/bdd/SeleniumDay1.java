package com.capg.bdd;

import java.util.ArrayList;

import javax.sql.rowset.serial.SerialArray;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByClassName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumDay1 {
	public static void main(String[] args) {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\NILANSAH\\Desktop\\Testing mod 4\\chromedriverLatest\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		driver.get("http://www.google.com/");
		
		
		WebElement searchelement = driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div[1]/div[1]/div/div[2]/input"));
		searchelement.sendKeys("Amazon");
		searchelement.submit();
		
		WebElement searchelement1 = driver.findElement(By.xpath("//*[@id=\"rso\"]/div[1]/div/div[1]/div/div/div[1]/a/h3/span"));
		searchelement1.click();
		
		WebElement searchelement2 = driver.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"]"));
		searchelement2.sendKeys("iPhone XR");
		searchelement2.submit();
		
		String winHandleBefore = driver.getWindowHandle();
		WebElement searchelement3 = driver.findElement(By.xpath("//*[@id=\"search\"]/div[1]/div[2]/div/span[4]/div[1]/div[1]/div/span/div/div/div/div/div[2]/div[2]/div/div[1]/div/div/div[1]/h2/a/span"));
		searchelement3.click();
		
		
		 ArrayList<String> newTab = new ArrayList<String>(driver.getWindowHandles());
         newTab.remove(winHandleBefore);
         // change focus to new tab
         driver.switchTo().window(newTab.get(0));
		
		
		WebElement searchelement4 = driver.findElement(By.xpath("//*[@id=\"buy-now-button\"]"));
		searchelement4.submit();
		
		WebElement searchelement5 = driver.findElement(By.xpath("//*[@id=\"hlb-ptc-btn-native\"]"));
		searchelement5.click();
		
         
         // change focus to new tab
		
		
		WebElement searchelement6 = driver.findElement(By.xpath("//*[@id=\"ap_email\"]"));
		searchelement6.sendKeys("7081615618");
		searchelement6.submit();
		
		WebElement searchelement7 = driver.findElement(By.xpath("//*[@id=\"ap_password\"]"));
		searchelement7.sendKeys("wishmeon25");
		searchelement7.submit();
		
		
		
         
                  
		///html/body/div[4]/div[2]/div[4]/div[7]/div[7]/div/div/div[1]/div/div/div[2]/div/div[2]/div/form/div[1]/div/div[22]/div/div/span/span/input
		
}
}
