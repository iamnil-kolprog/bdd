package StepDefinition;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import Bean.EducationDetails;
import Bean.Registration;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StpDef {
	
	WebDriver driver;
	Registration reg;
	EducationDetails ed;
	
	@Given("^User is on Registration Form page$")
	public void user_is_on_Registration_Form_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\NILANSAH\\Desktop\\Testing mod 4\\chromedriverLatest\\chromedriver.exe");
		driver = new ChromeDriver();
	    reg=new Registration(driver);
		driver.manage().window().maximize();
		driver.get("file:///C:/Users/NILANSAH/Desktop/Testing%20mod%204/SET03/SET03/WebPages/PersonalDetails.html#");
	}

	@Then("^Title should be \"Welcome to Personal Details\\.$")
	public void title_should_be_Welcome_to_JobsWorld()  {
	    // Write code here that turns the phrase above into concrete actions
		String title="Personal Details";
		assertEquals(title,driver.getTitle());
		
	    
	}

	@When("^Submit button is clicked without entering First_Name$")
	public void submit_button_is_clicked_without_entering_First_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reg.setfName("");
		Thread.sleep(500);
		reg.getNext().click();
	   
	}

	@Then("^error message should be displayed as \"([^\"]*)\"$")
	public void error_message_should_be_displayed_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert,arg1);
		driver.switchTo().alert().accept();
		//driver.quit();
		
	}
	
	@When("^Submit button is clicked without entering Last_Name$")
	public void submit_button_is_clicked_without_entering_Last_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reg.setfName("Nilanjan");
		Thread.sleep(500);
		reg.setlName("");
		Thread.sleep(500);
		reg.setNext();
	}
//	 
	@When("^Submit button is clicked without entering Email$")
	public void submit_button_is_clicked_without_entering_Email() throws Throwable {
		reg.setlName("Saha");
	    Thread.sleep(500);
	    reg.setEmail("");
	    Thread.sleep(500);
	    reg.setNext();
	}

	@When("^Submit button is clicked entered by wrong format like \"([^\"]*)\"$")
	public void submit_button_is_clicked_entered_by_wrong_format_like(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    reg.setEmail(arg1);
	    Thread.sleep(500);
	    reg.setNext();
	}
	@When("^Submit button is clicked without entering Contact_No$")
	public void submit_button_is_clicked_without_entering_Contact_No() throws Throwable {

		reg.getEmail().clear();
		Thread.sleep(300);
	    reg.setEmail("nilsaha97@gmail.com");
	    Thread.sleep(500);
	    reg.setPhone("");
	    reg.setNext();
	}
	@When("^Submit button is clicked entered by wrong format in contact like \"([^\"]*)\"$")
	public void submit_button_is_clicked_entered_by_wrong_format_in_contact_like(String arg1) throws Throwable {
	    
	    reg.setPhone(arg1);
		//reg.setPhone("9889985624");
	    Thread.sleep(500);
	    reg.setNext();

	}
	@When("^Submit button is clicked without entering first address line$")
	public void submit_button_is_clicked_without_entering_first_address_line() throws Throwable {
	    
		
		reg.getPhone().clear();
		reg.setPhone("9859478592");
	    Thread.sleep(500);
	    reg.setAdd1("");
	    
	    reg.setNext();
	}

	@When("^Submit button is clicked without entering second address line$")
	public void submit_button_is_clicked_without_entering_second_address_line() throws Throwable {
		reg.setAdd1("35ffgfg4d");
	    Thread.sleep(500);
	    reg.setAdd2("");
	    reg.setNext();

	}

	@When("^Submit button is clicked without selecting the city$")
	public void submit_button_is_clicked_without_selecting_the_city() throws Throwable {
	    reg.setAdd2("abncvd232");
	    reg.setNext();
	    Thread.sleep(500);
	}

	@When("^Submit button is clicked without selecting the state$")
	public void submit_button_is_clicked_without_selecting_the_state() throws Throwable {
	    reg.setCity("Pune");
	    Thread.sleep(500);
	    reg.setNext();
	    Thread.sleep(500);
	}
	
	
	@When("^Submit button is clicked After Validations$")
	public void submit_button_is_clicked_After_Validations() throws Throwable {
	   reg.setState("Karnataka");
	   reg.setNext(); 
	}

	@Then("^alert message should come with as \"([^\"]*)\"$")
	public void alert_message_should_come_with_as(String arg1) throws Throwable {
	    
	   String st = driver.switchTo().alert().getText();
	   assertEquals(arg1,st);
	   driver.switchTo().alert().accept();

	}
	
	
	//EDUCATION
	
	@Given("^User is on Educational page$")
	public void user_is_on_Educational_page() throws Throwable {
		 
		 ed=new EducationDetails(driver);

		 ed.getRegister().submit();
		 
	    
	}

	@Then("^Title should be \"([^\"]*)\"$")
	public void title_should_be(String arg1) throws Throwable {
	   //String s =driver.switchTo().alert().getText();
		assertEquals(arg1,driver.getTitle());
	    
	}
	
	@When("^User is clicking the submit button without selecting the graduation field$")
	public void user_is_clicking_the_submit_button_without_selecting_the_graduation_field() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    ed.setGrad("");
	    Thread.sleep(500);
	    ed.getRegister().click();
	    Thread.sleep(500);
	}

	@Then("^alert message should come as \"([^\"]*)\"$")
	public void alert_message_should_come_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   String altmsg= driver.switchTo().alert().getText();
	   assertEquals(altmsg,arg1);
	   driver.switchTo().alert().accept();
	}

	@When("^User is submitting without entering the Percentage field$")
	public void user_is_submitting_without_entering_the_Percentage_field() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Select grada=new Select(driver.findElement(By.name("graduation")));
        grada.selectByVisibleText("BTech");
        Thread.sleep(500);
        ed.setPerc("");
        ed.getRegister().click();
	}

	@When("^User is submitting without entering the Passing Year$")
	public void user_is_submitting_without_entering_the_Passing_Year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
		ed.setPerc("80%");
		Thread.sleep(500);
		ed.setPassingY("");
		Thread.sleep(500);
		ed.getRegister().click();
	}

	@When("^User is submitting without entering the Project Name$")
	public void user_is_submitting_without_entering_the_Project_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   ed.setPassingY("2019");
	   Thread.sleep(500);
	   ed.setProj("");
	   Thread.sleep(500);
	   ed.getRegister().click();
	}
	@When("^User is submitting without clicking the Technologies Used$")
	public void user_is_submitting_without_clicking_the_Technologies_Used() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    ed.setProj("abcd");
	    ed.getRegister().click();
	    Thread.sleep(1000);
	}

	@When("^User is submitting without writing the Other Technologies$")
	public void user_is_submitting_without_clicking_the_Other_Technologies() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		ed.getJava().click();
		ed.getOther().click();
		ed.getRegister().click();
		Thread.sleep(1000);

	}
	@When("^User is submitting with all the details$")
	public void user_is_submitting_with_all_the_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   ed.setoTech("Python");
	   ed.getRegister().click();
	   Thread.sleep(500);
	}

	@Then("^Alert message should be displayed as \"([^\"]*)\"$")
	public void alert_message_should_be_displayed_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    assertEquals(driver.switchTo().alert().getText(),arg1);
	    driver.switchTo().alert().accept();
	}

	
	
	

}
