package Registration;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(glue= {"StepDefinition"})
public class TestRegister {

}


//When Submit button is clicked entered by wrong format in contact like "6652565455"
//Then error message should be displayed as "Please enter valid Contact no."