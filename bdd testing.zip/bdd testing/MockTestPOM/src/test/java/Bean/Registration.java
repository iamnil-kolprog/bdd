package Bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Registration {
	
	WebDriver drive;
	

	 public Registration(WebDriver drive) {
		super();
		this.drive = drive;
		PageFactory.initElements(drive, this);
	}

	 	@FindBy(id = "txtFirstName")
	    @CacheLookup
	    WebElement fName;
	    
	    @FindBy(id = "txtLastName")
	    @CacheLookup
	    WebElement lName;
	    
	    @FindBy(id = "txtEmail")
	    @CacheLookup
	    WebElement email;
	    
	    @FindBy(id = "txtPhone")
	    @CacheLookup
	    WebElement phone;
	    
	    @FindBy(id = "txtAddress1")
	    @CacheLookup
	    WebElement add1;
	    
	    @FindBy(id = "txtAddress2")
	    @CacheLookup
	    WebElement add2;
	    
	    @FindBy(name = "city")
	    @CacheLookup
	    WebElement city;
	    
	    @FindBy(name = "state")
	    @CacheLookup
	    WebElement state;
	    
	    @FindBy(xpath ="/html/body/form/table/tbody/tr[11]/td/a")
	    @CacheLookup
	    WebElement next;

		public WebElement getfName() {
			return fName;
		}
//		public void setfName(WebElement fName) {
//			this.fName = fName;
//		}

		public void setfName(String Name) {
			this.fName.sendKeys(Name);
		}

		public WebElement getlName() {
			return lName;
		}

		public void setlName(String lName) {
			this.lName.sendKeys(lName);;
		}

		public WebElement getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email.sendKeys(email);
		}

		public WebElement getPhone() {
			return phone;
		}

		public void setPhone(String phone) {
			this.phone.sendKeys(phone);
		}

		public WebElement getAdd1() {
			return add1;
		}

		public void setAdd1(String string) {
			this.add1.sendKeys(string);
		}

		public WebElement getAdd2() {
			return add2;
		}

		public void setAdd2(String string) {
			this.add2.sendKeys(string);
		}

		public WebElement getCity() {
			return city;
		}

		public void setCity(String string) {
			this.city.sendKeys(string);
		}

		public WebElement getState() {
			return state;
		}

		public void setState(String string) {
			this.state.sendKeys(string);
		}

		public WebElement getNext() {
			return next;
		}

		public void setNext() {
			this.next.click();
		}
}
