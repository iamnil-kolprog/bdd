package Bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EducationDetails {
	
	WebDriver drive;
	public EducationDetails(WebDriver drive) {
		super();
		this.drive = drive;
		PageFactory.initElements(drive, this);
	}
	
	@FindBy(name="graduation")
	WebElement grad;
	
	@FindBy(name="percentage")
	WebElement perc;
	
	@FindBy(name="passingYear")
	WebElement passingY;
	
	@FindBy(name="projectName")
	WebElement proj;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/input[1]")
	WebElement techDN;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/input[2]")
	WebElement java;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/input[3]")
	WebElement php;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/input[4]")
	WebElement other;
	
	public WebElement getJava() {
		return java;
	}

	public WebElement getPhp() {
		return php;
	}

	public WebElement getOther() {
		return other;
	}

	@FindBy(id="btnRegister")
	WebElement register;
	
	@FindBy(name="otherTechnologies")
	WebElement oTech;
	public void setDrive(WebDriver drive) {
		this.drive = drive;
	}

	public void setGrad(String grad) {
		this.grad.sendKeys(grad);
	}

	public void setPerc(String string) {
		this.perc.sendKeys(string);
	}

	public void setPassingY(String string) {
		this.passingY.sendKeys(string);
	}

	public void setProj(String string) {
		this.proj.sendKeys(string);
	}

	public WebElement getTech() {
		return techDN;
	}

	public WebElement getoTech() {
		return oTech;
	}

	public void setTech(WebElement tech) {
		this.techDN = tech;
	}

	public void setRegister(WebElement register) {
		this.register = register;
	}

	public void setoTech(String string) {
		this.oTech.sendKeys(string);
	}

	public WebElement getRegister() {
		return register;
	}

	

}
