package com.cg.pageRepo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PersonalDetails 
{
	WebDriver driver;

	public PersonalDetails(WebDriver driver)
	{
		this.driver = driver;
	}
	
	@FindBy(id="txtFirstName")
	WebElement fName;
	
	@FindBy(id="txtLastName")
	WebElement lName;
	
	@FindBy(id="txtEmail")
	WebElement email;
	
	@FindBy(id="txtPhone")
	WebElement ph;
	
	@FindBy(id="txtAddress1")
	WebElement add1;
	
	@FindBy(id="txtAddress2")
	WebElement add2;
	
	@FindBy(name="city")
	WebElement ct;
	
	@FindBy(name="state")
	WebElement st;
	
	@FindBy(xpath="/html/body/h4")
	WebElement hd;

	public WebElement getHd() {
		return hd;
	}

	public void setHd(WebElement hd) {
		this.hd = hd;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getfName() {
		return fName;
	}

	public WebElement getlName() {
		return lName;
	}

	public WebElement getEmail() {
		return email;
	}

	public WebElement getPh() {
		return ph;
	}

	public WebElement getAdd1() {
		return add1;
	}

	public WebElement getAdd2() {
		return add2;
	}

	public WebElement getCt() {
		return ct;
	}

	public WebElement getSt() {
		return st;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public void setfName(WebElement fName) {
		this.fName = fName;
	}

	public void setlName(WebElement lName) {
		this.lName = lName;
	}

	public void setEmail(WebElement email) {
		this.email = email;
	}

	public void setPh(WebElement ph) {
		this.ph = ph;
	}

	public void setAdd1(WebElement add1) {
		this.add1 = add1;
	}

	public void setAdd2(WebElement add2) {
		this.add2 = add2;
	}

	public void setCt(WebElement ct) {
		this.ct = ct;
	}

	public void setSt(WebElement st) {
		this.st = st;
	}
		
}
