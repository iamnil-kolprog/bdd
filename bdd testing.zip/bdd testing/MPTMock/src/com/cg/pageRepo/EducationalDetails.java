package com.cg.pageRepo;

public class EducationalDetails {

}
