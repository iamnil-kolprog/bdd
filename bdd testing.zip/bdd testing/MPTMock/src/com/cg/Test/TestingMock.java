package com.cg.Test;
import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.pageRepo.PersonalDetails;




public class TestingMock 
{
	
	
	@Test
	public void verifyTitle()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\NILANSAH\\Desktop\\Testing mod 4\\chromedriverLatest\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("file:///C:/Users/NILANSAH/Desktop/Testing%20mod%204/SET03/SET03/WebPages/PersonalDetails.html#");
		PersonalDetails pd = PageFactory.initElements(driver, PersonalDetails.class);
		
		assertEquals(driver.getTitle(), "Personal Details");		
	}
	
	
	
	

}


